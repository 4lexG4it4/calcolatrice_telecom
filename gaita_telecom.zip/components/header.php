<!-- Navbar Aggiunta -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Telecomunicazioni</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="doc/spi_telecom0.php">Spiegazione</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="doc/spi_telecom1.php">Legge di Kirchhoff</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="doc/spi_telecom2.php">Principio di Sovrapposizione</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="doc/esercizio.php">Esercizio</a>
            </li>
        </ul>
    </div>
</nav>
<!-- Fine Navbar -->