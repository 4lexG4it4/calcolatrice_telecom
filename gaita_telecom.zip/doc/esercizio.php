<!DOCTYPE html>
<html lang="it">
<?php include_once "../components/head_doc.php";?>
<body>
<?php include_once "../components/header_doc.php"; ?>
<div class="container  mt-5">
    <h1>
        Esercizio alternativo
    </h1>

    <div class="card">
        <div class="card-header">Ecco la descrizione del circuito per l'esercizio:
        </div>
        <div class="card-body">
            <p>
            Due generatori di corrente:
            </p>
            <p>
            I¹ = 2A (generatore di corrente 1) <br>I²= 3A (generatore di corrente2)
            </p>
            <p>
            Due resistenze:
            </p>
            <p>
            R¹=4î(resistenza1) <br> R²=6Î(resistenza2)
            </p>
            <p>
            Il circuito avrà una configurazione con i due generatori in posizioni diverse per applicare il principio di sovrapposizione.
            </p>
            <img src="../images/1.jpg" alt="Principio di Sovrapposizione degli Effetti" style="max-width: 100%; height: auto; display: block; margin: 0 auto;">
        </div>
    </div>

    
</body>
</html>
