<!DOCTYPE html>
<html lang="it">
<?php include_once "../components/head_doc.php";?>
<body>
<?php include_once "../components/header_doc.php"; ?>
<div class="container  mt-5">
    <h1>Informazioni su Tensione, Corrente e Resistenza</h1>

    <div class="card">
        <div class="card-header">Tensione (Volt)</div>
        <div class="card-body">
            <p>
                La <strong>tensione</strong>, misurata in Volt (V), rappresenta la "pressione" che spinge gli elettroni a muoversi lungo un circuito. 
                È come la forza che provoca il flusso di elettricità attraverso i fili. Una tensione più alta significa una spinta maggiore.
            </p>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">Corrente (Ampere)</div>
        <div class="card-body">
            <p>
                La <strong>corrente</strong>, misurata in Ampere (A), rappresenta la quantità di elettroni che fluisce attraverso un circuito in un determinato momento.
                Maggiore è la corrente, più elettroni stanno attraversando il circuito. La corrente è il "flusso" di elettricità generato dalla tensione.
            </p>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">Resistenza (Ohm)</div>
        <div class="card-body">
            <p>
                La <strong>resistenza</strong>, misurata in Ohm (Ω), indica la difficoltà con cui gli elettroni riescono a passare attraverso un materiale. 
                Maggiore è la resistenza, più difficile sarà per gli elettroni fluire. La resistenza è un fattore che limita la corrente in un circuito.
            </p>
        </div>
    </div>

    
</div>

</body>
</html>
