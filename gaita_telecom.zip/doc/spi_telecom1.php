<!DOCTYPE html>
<html lang="it">
<?php include_once "../components/head_doc.php";?>
<body>
<?php include_once "../components/header_doc.php"; ?>
<div class="container  mt-5">
    <h1>Legge di Kirchhoff</h1>

    <div class="card">
        <div class="card-header">Spiegazione Legge di Kirchhoff</div>
        <div class="card-body">
            <p>
                Le <strong>leggi di Kirchhoff</strong> aiutano a analizzare i circuiti elettrici. 
                La prima dice che la corrente che entra in un punto (<a href="http://www.die.ing.unibo.it/pers/cristofo/didattica/dispense/03circdf.pdf" target="_blank">nodo</a>) è uguale a quella che esce. La seconda afferma che la somma delle tensioni in un circuito chiuso è zero.
            </p>
            <img src="https://i.ytimg.com/vi/VAW35Z5-0BA/sddefault.jpg" alt="Schema del circuito con leggi di Kirchhoff" style="max-width:100%; height: auto;">
        </div>
    </div>

    
</div>

</body>
</html>
