<!DOCTYPE html>
<html lang="it">
<?php include_once "components/head.php";?>
<body>

<?php include_once "components/header.php"; ?>

<div class="container mt-5">
    <h1>Calcolatrice di Telecomunicazioni</h1>
    <div class="card">
        <div class="card-header">
            Inserisci i valori
        </div>
        <div class="card-body">
            <form id="calcForm">
                <div class="form-group">
                    <label for="voltage">Tensione (Volt)</label>
                    <input type="number" class="form-control" id="voltage" placeholder="Inserisci la tensione" />
                </div>
                <div class="form-group">
                    <label for="current">Corrente (Ampere)</label>
                    <input type="number" class="form-control" id="current" placeholder="Inserisci la corrente" />
                </div>
                <div class="form-group">
                    <label for="resistance">Resistenza (Ohm)</label>
                    <input type="number" class="form-control" id="resistance" placeholder="Inserisci la resistenza" />
                </div>
                <button type="button" name="calcola" id="calcola" class="btn btn-primary mt-3" onclick="calculate()">Calcola</button>
                <button type="button" class="btn btn-secondary mt-3 ml-2" onclick="resetFields()">Reset</button>
            </form>
        </div>
    </div>

    <h3 class="mt-4">Risultato:</h3>
    <p id="result" class="p-3 mt-2"></p>
</div>


<script>
    // Get the input field
var input1 = document.getElementById("voltage");
var input2 = document.getElementById("current");
var input = document.getElementById("resistance");

// Execute a function when the user presses a key on the keyboard
input.addEventListener("keypress", function(event) {
    console.log("primo passo");
  // If the user presses the "Enter" key on the keyboard
  if (event.key === "Enter") {
    // Cancel the default action, if needed
    event.preventDefault();
    // Trigger the button element with a click
    document.getElementById("calcola").click();
  }
});
input2.addEventListener("keypress", function(event) {
    console.log("primo passo");
  // If the user presses the "Enter" key on the keyboard
  if (event.key === "Enter") {
    // Cancel the default action, if needed
    event.preventDefault();
    // Trigger the button element with a click
    document.getElementById("calcola").click();
  }
});
input1.addEventListener("keypress", function(event) {
    console.log("primo passo");
  // If the user presses the "Enter" key on the keyboard
  if (event.key === "Enter") {
    // Cancel the default action, if needed
    event.preventDefault();
    // Trigger the button element with a click
    document.getElementById("calcola").click();
  }
});
</script>
</body>
</html>
